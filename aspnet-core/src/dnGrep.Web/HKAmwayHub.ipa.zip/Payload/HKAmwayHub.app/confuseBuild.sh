
# 格式："\033[字背景颜色; 字体颜色m 将要设置的字符串 \033[0m"

# 字体颜色: 30 --- 37
# 30: 黑
# 31: 红
# 32: 绿
# 33: 黄
# 34: 蓝色
# 35: 紫色
# 36: 深绿
# 37: 白色

# 字体背景颜色: 40 --- 47
# 40: 黑
# 41: 深红
# 42: 绿
# 43: 黄色
# 44: 蓝色
# 45: 紫色
# 46: 深绿
# 47: 白色

# 字体加亮颜色: 90 --- 97
# 90: 黑
# 91: 红
# 92: 绿
# 93: 黄
# 94: 蓝色
# 95: 紫色
# 96: 深绿
# 97: 白色

# 背景加亮颜色范围: 100 --- 107
# 100: 黑
# 101: 深红
# 102: 绿
# 103: 黄色
# 104: 蓝色
# 105: 紫色
# 106: 深绿
# 107: 白色

# \33[0m 关闭所有属性
# \33[1m 设置高亮度
# \33[4m 下划线
# \33[5m 闪烁
# \33[7m 反显
# \33[8m 消隐
# \33[30m -- \33[37m 设置前景色
# \33[40m -- \33[47m 设置背景色
# \33[nA 光标上移n行
# \33[nB 光标下移n行
# \33[nC 光标右移n行
# \33[nD 光标左移n行
# \33[y;xH设置光标位置
# \33[2J 清屏
# \33[K 清除从光标到行尾的内容
# \33[s 保存光标位置
# \33[u 恢复光标位置
# \33[?25l 隐藏光标
# \33[?25h 显示光标
# \x1b[2J\x1b[$;1H    $表示行位


# 参数选项
options() {
    echo "\033[0;31m"
    echo "参数: [-u, -c]"
    echo "  -u 清理混淆回到未混淆的时候"
    echo "  -c 去混淆 备份 混淆"
    echo "\033[0m"
}

# 配置info
info() {
    local green="\033[1;32m"
    local normal="\033[0m"
    echo "[${green}info${normal}] $1"
}

#要混淆前缀
CONFUSE_PREFIX="mix__"

#混淆标记文件
CONFUSE_FLAG=".confuseFlag"

#恢复回混淆前文件
BACKUP_FILE=".backup.log"

#象征文件
SYMBOL_FILE=".symbol.log"

# 混淆文件
CONFUSE_FILE=".confuse.log"

#删除存在的文件
removeIfExist(){
    if [ -f $1 ]; then
        rm $1
    fi
}

# 备份文件
backupFile() {
    file=$1
    # 在原文件名前加个. (点符合)用作备份名
    fileName=${file##*/}
    backupPath=${file/$fileName/.$fileName$BACKUP_EXTENSION}
    echo "backup $file to $backupPath"

    if [ ! -f $backupPath ]; then
        cp $file $backupPath
        echo $backupPath >>$BACKUP_FILE
    fi
}

SOURCE_ARRAY=("*.swift" "*.m" "*.h" "*.c" "*.cpp")

BACKUP_EXTENSION=".bak"

# 随机生成字符串
randomString() {
    openssl rand -base64 64 | tr -cd 'a-zA-Z' | head -c 16
}

# 获取符号随机字符串
randomStringWithSymbol() {
    grep -w $1 $SYMBOL_FILE -h | cut -d \  -f 2
}

if [ -z "$PROJECT_NAME" ]; then
    CONFUSE_DIR="."
else
#    CONFUSE_DIR="${SRCROOT}"
    CONFUSE_DIR="${SRCROOT}/${PROJECT_NAME}"
    CONFUSE_DIR_BC="${SRCROOT}/BC"
    CONFUSE_DIR_Common="${SRCROOT}/Common"
    CONFUSE_DIR_Util="${SRCROOT}/Util"
    CONFUSE_DIR_XRCarouselView="${SRCROOT}/XRCarouselView"
#     echo "9090909"$CONFUSE_DIR
#    CONFUSE_DIR="${SRCROOT}/${PROJECT_NAME}"
fi

main() {
    
    case $1 in

        "-u")
        echo "清理混淆回到未混淆的时候"
        unconfuse
        ;;

        "-c")
        echo "去混淆 备份 混淆"
        safeConfuse
        ;;

        *)
            echo "请添加您要选择的参数选项"
            options
        ;;

    esac
}

# 清理，去混淆
unconfuse() {

    info "混淆清理中..."
    if [ -f $CONFUSE_FLAG ]; then
        #恢复混淆的函数名所在Source文件bak内容
        cat $BACKUP_FILE | while read backup; do
            backupName=${backup##*/}
            fileName=`echo $backupName | cut -d "." -f2,3`
            filePath=${backup/$backupName/$fileName}

            echo "recover $backup to $filePath"
            cp $backup $filePath
            rm $backup
        done

        # 删除修改记录
        removeIfExist $SYMBOL_FILE
        removeIfExist $CONFUSE_FILE
        removeIfExist $BACKUP_FILE
        removeIfExist $CONFUSE_FLAG
    else
        echo "没有混淆!!!"
    fi
    info "混淆清理完成"
}

#检查上次是否未完成
precheck() {
    # 创建一个隐藏文件，标记混淆编译状态
    # 由于编译过程中可能被中断，因此混淆后的代码可能未恢复，在开始备份前先做判断
    unconfuse
    touch $CONFUSE_FLAG
}

# 备份所有source文件
backupAllSource() {
    info "备份所有Swift文件"
    NAMES="-name \"${SOURCE_ARRAY[0]}\""
    i=1
    while [ $i -lt ${#SOURCE_ARRAY[@]} ] 
    do
        NAMES+=" -or -name \"${SOURCE_ARRAY[$i]}\""
        let i++
    done
    # -name "*.swift" -or -name "*.m" -or -name "*.h" -or -name "*.c" -or -name "*.cpp"
#        echo "000000000000" $NAMES
    removeIfExist $BACKUP_FILE
    touch $BACKUP_FILE

    eval "find $CONFUSE_DIR $NAMES" | while read file; do
        backupFile $file
    done
    
    eval "find $CONFUSE_DIR_BC $NAMES" | while read file; do
        backupFile $file
    done
    
    eval "find $CONFUSE_DIR_Common $NAMES" | while read file; do
        backupFile $file
    done
    
    eval "find $CONFUSE_DIR_Util $NAMES" | while read file; do
        backupFile $file
    done
    
    eval "find $CONFUSE_DIR_XRCarouselView $NAMES" | while read file; do
        backupFile $file
    done
    
    
        
}

# 真正开始混淆工作
confuseOnly() {
    info "开始混淆中..."

    # 获取要混淆的函数名和变量名
    INCLUDES="--include=\"${SOURCE_ARRAY[0]}\""
    j=1
    while [ $j -lt ${#SOURCE_ARRAY[@]} ]
    do
        INCLUDES+=" --include=\"${SOURCE_ARRAY[$j]}\""
        let j++
    done
    
#    --include="*.swift" --include="*.m" --include="*.h" --include="*.c" --include="*.cpp"
    #echo "111111111111" $INCLUDES

    eval "grep $CONFUSE_PREFIX -r $CONFUSE_DIR $INCLUDES -n" >$CONFUSE_FILE
    eval "grep $CONFUSE_PREFIX -r $CONFUSE_DIR_BC $INCLUDES -n" >>$CONFUSE_FILE
    eval "grep $CONFUSE_PREFIX -r $CONFUSE_DIR_Common $INCLUDES -n" >>$CONFUSE_FILE
    eval "grep $CONFUSE_PREFIX -r $CONFUSE_DIR_Util $INCLUDES -n" >>$CONFUSE_FILE
    eval "grep $CONFUSE_PREFIX -r $CONFUSE_DIR_XRCarouselView $INCLUDES -n" >>$CONFUSE_FILE
    
    # 绑定随机字符串
    removeIfExist $SYMBOL_FILE
    touch $SYMBOL_FILE

    cat $CONFUSE_FILE | egrep -w $CONFUSE_PREFIX"[0-9a-zA-Z_]*" -o | sort | uniq | while read line; do
        echo $line" `randomString`" >>$SYMBOL_FILE
        #echo "121212"$line #121212mix__ISSNetworkTool
    done
    



    #读取备份文件记录
    cat $CONFUSE_FILE | while read line; do
        
        # 截取行号
        lineNum=`echo $line | sed 's/.*:\([0-9]*\):.*/\1/g'`

        # 截取文件路径
        path=${line%%:*}

        echo $line | egrep -w $CONFUSE_PREFIX"[0-9a-zA-Z_]*" -o | sort -r | while read -ra symbol; do
            # 根据名称获取绑定的随机字符串
            random=`randomStringWithSymbol $symbol`

            sed -i "" "${lineNum}s/$symbol/$random/g" $path
            echo " $symbol => $random"
        done
    done

    info "混淆完成"
}

# 去混淆，备份，混淆
safeConfuse() {
    precheck
    backupAllSource
    confuseOnly
}

main $@
